﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace MonoGameWindowsStarter
{
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Balloon balloon;
        Paddle paddle;
        public float wind;
        public Random random = new Random();
        KeyboardState oldKeyboardState;
        KeyboardState newKeyboardState;
        TimeSpan windTimer;
        SpriteFont spriteFont;
        string windDir;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            paddle = new Paddle(this);
            balloon = new Balloon(this);
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            graphics.PreferredBackBufferWidth = 1042;
            graphics.PreferredBackBufferHeight = 768;
            graphics.ApplyChanges();
            balloon.Initialize();
            paddle.Initialize();
            base.Initialize();
            wind = (float)random.NextDouble() - .5f;
            windTimer = new TimeSpan(0, 0, 0);
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            balloon.LoadContent(Content);
            paddle.LoadContent(Content);
            spriteFont = Content.Load<SpriteFont>("defaultFont");
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            windTimer = windTimer.Add(gameTime.ElapsedGameTime).Duration();
            if (windTimer.Duration().Seconds >= 15)
            {
                balloon.windSound.Play();
                wind = (float)random.NextDouble() - .5f;
                windTimer -= new TimeSpan(0, 0, 15);
            }
            if (wind < 0)
            {
                windDir = "Left";
            }
            else
            {
                windDir = "Right";
            }
            newKeyboardState = Keyboard.GetState();

            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            if (newKeyboardState.IsKeyDown(Keys.Escape))
                Exit();

            paddle.Update(gameTime);
            balloon.Update(gameTime);

            if (balloon.Bounds.CollidesWith(paddle.Bounds))
            {
                balloon.bounceSound.Play();
                balloon.Velocity.Y = -1.5f;
            }

            oldKeyboardState = newKeyboardState;
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.SkyBlue);
            spriteBatch.Begin();

            spriteBatch.DrawString(
                spriteFont,
                $"Wind: {windDir} at {Math.Abs(wind)*50} mph",
                Vector2.Zero,
                Color.White
                );

            balloon.Draw(spriteBatch);
            paddle.Draw(spriteBatch);

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
