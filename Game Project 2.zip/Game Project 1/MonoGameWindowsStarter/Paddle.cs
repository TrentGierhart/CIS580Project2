﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input;
using System;

namespace MonoGameWindowsStarter
{
    class Paddle
    {
        Game1 game;

        public BoundingRectangle Bounds;

        Texture2D texture;

        private float speed;

        const int ANIM_FRAME_RATE = 88;
        const int FRAME_WIDTH = 100;
        TimeSpan animTimer;
        int frame;

        enum State
        {
            Idle = 0,
            Moving = 1
        }

        State state;

        public Paddle(Game1 game)
        {        
            this.game = game;
        }

        public void LoadContent(ContentManager content)
        {
            texture = content.Load<Texture2D>("paddle");
        }

        public void Initialize()
        {
            speed = .6f;
            Bounds.Width = 100;
            Bounds.Height = 50;
            Bounds.X = game.GraphicsDevice.Viewport.Width / 2 - Bounds.Width / 2;
            Bounds.Y = game.GraphicsDevice.Viewport.Height - Bounds.Height;
            state = State.Idle;
            animTimer = new TimeSpan(0);
            frame = 1;
        }

        public void Update(GameTime gameTime)
        {
            var keyboardState = Keyboard.GetState();

            // Move the paddle left if the left key is pressed
            if (keyboardState.IsKeyDown(Keys.Left))
            {
                // move left
                state = State.Moving;
                Bounds.X -= (float)gameTime.ElapsedGameTime.TotalMilliseconds * speed;
            }

            // Move the paddle right if the right key is pressed
            if (keyboardState.IsKeyDown(Keys.Right))
            {
                // move right
                state = State.Moving;
                Bounds.X += (float)gameTime.ElapsedGameTime.TotalMilliseconds * speed;
            }

            if (!(keyboardState.IsKeyDown(Keys.Left) || keyboardState.IsKeyDown(Keys.Right)))
            {
                state = State.Idle;
            }

            // Stop the paddle from going off-screen
            if (Bounds.X < 0)
            {
                Bounds.X = 0;
            }
            if (Bounds.X > game.GraphicsDevice.Viewport.Width - Bounds.Width)
            {
                Bounds.X = game.GraphicsDevice.Viewport.Width - Bounds.Width;
            }

            if (state != State.Idle) animTimer += gameTime.ElapsedGameTime;

            while (animTimer.TotalMilliseconds > ANIM_FRAME_RATE)
            {
                frame++;
                animTimer -= new TimeSpan(0, 0, 0, 0, ANIM_FRAME_RATE);
            }
            frame %= 8;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            var source = new Rectangle(
                frame * FRAME_WIDTH, // X value 
                0, // Y value
                FRAME_WIDTH, // Width 
                (int)Bounds.Height // Height
                );

            // render the sprite
            spriteBatch.Draw(texture, new Vector2(Bounds.X, Bounds.Y), source, Color.White);
        }
    }
}
