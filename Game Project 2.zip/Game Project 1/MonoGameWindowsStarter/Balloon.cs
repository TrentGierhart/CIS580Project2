﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Audio;
using System;

namespace MonoGameWindowsStarter
{
    class Balloon
    {
        Game1 game;

        Texture2D texture;

        public BoundingCircle Bounds;

        public Vector2 Velocity;

        public SoundEffect windSound;

        public SoundEffect bounceSound;

        public Balloon(Game1 game)
        {
            this.game = game;
        }

        public void Initialize()
        {
            Bounds.Radius = 25;

            Bounds.X = game.GraphicsDevice.Viewport.Width / 2;
            Bounds.Y = game.GraphicsDevice.Viewport.Height / 2;

            Velocity = new Vector2(
                0,
                -5
            );
            Velocity.Normalize();
        }

        public void LoadContent(ContentManager content)
        {
            texture = content.Load<Texture2D>("balloon");
            bounceSound = content.Load<SoundEffect>("Jump");
            windSound = content.Load<SoundEffect>("wind");
        }

        public void Update(GameTime gameTime)
        {
            var viewport = game.GraphicsDevice.Viewport;

            Velocity.Y += (float)gameTime.ElapsedGameTime.TotalMilliseconds / 800;
            if (Math.Abs(Velocity.X) <= 2.5f)//Math.Abs(Velocity.X) <= Math.Abs(game.wind * 20) && 
            {
                Velocity.X += game.wind / 100;
            }

            Bounds.Center += (float)gameTime.ElapsedGameTime.TotalMilliseconds / 2 * Velocity;

            // Check for wall collisions
            if (Bounds.Center.Y < Bounds.Radius)
            {
                Velocity.Y *= -1;
                float delta = Bounds.Radius - Bounds.Y;
                Bounds.Y += 2 * delta;
            }

            if (Bounds.Center.Y > viewport.Height)
            {
                Velocity.Y = 0;
                Bounds.Center = new Vector2(viewport.Width / 2, viewport.Height / 4);
            }

            if (Bounds.X - Bounds.Radius < 0)
            {
                Velocity.X *= -1;
                float delta = Bounds.Radius - Bounds.X;
                Bounds.X += 2 * delta;
            }

            if (Bounds.X > viewport.Width - Bounds.Radius)
            {
                Velocity.X *= -1;
                float delta = viewport.Width - Bounds.Radius - Bounds.X;
                Bounds.X += 2 * delta;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, Bounds, Color.White);
        }
    }
}
